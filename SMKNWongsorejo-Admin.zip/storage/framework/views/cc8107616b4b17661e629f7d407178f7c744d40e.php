

<?php $__env->startSection('content'); ?>
<h4 class="fw-bold">
  <span class="text-muted fw-light">Admin /</span> Data Admin
</h4>
<button type="button" class="btn btn-primary mb-4" id="btnModal" data-bs-toggle="modal" data-bs-target="#modalForm">
  <span class="tf-icons bx bx-plus-circle"></span>&nbsp; Tambah Admin
</button>

<div class="card">
  <h5 class="card-header">List Data Admin</h5>
  <div class="table-responsive text-nowrap">
    <table class="table">
      <thead>
        <tr>
          <th>No.</th>
          <th></th>
          <th>Nama</th>
          <th>Username</th>
          <th>Role</th>
          <th>#</th>
        </tr>
      </thead>
      <tbody class="table-border-bottom-0">
        <?php $__empty_1 = true; $__currentLoopData = $dataAdmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($dataAdmin->firstItem()+$key); ?></td>
          <td>
            <?php if($admin->foto == ""): ?>
            <img src="<?php echo e(asset('foto-admin/user.png')); ?>" width="40px">
            <?php else: ?>
            <img src="<?php echo e(asset('foto-admin/'.$admin->foto)); ?>" width="40px">
            <?php endif; ?>
          </td>
          <td><?php echo e($admin->nama); ?></td>
          <td><?php echo e($admin->username); ?></td>
          <td><?php echo e($admin->role); ?></td>
          <td>
            <div class="dropdown">
            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
              <div class="dropdown-menu">
                <a class="dropdown-item" href="#" id="admin-edit-<?php echo e($admin->id); ?>" onClick="dataAdminEdit(this)" data-id="<?php echo e(base64_encode($admin->id)); ?>"><i class="bx bx-edit-alt me-1 text-primary"></i> Edit</a>
                <a class="dropdown-item" href="#" id="admin-del-<?php echo e($admin->id); ?>" onClick="dataAdminDel(this)" data-id="<?php echo e(base64_encode($admin->id)); ?>"><i class="bx bx-trash me-1 text-danger"></i> Hapus</a>
              </div>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="5">Data tidak ditemukan.</td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
    <div class="demo-inline-spacing">
      <nav aria-label="Page navigation">
        <?php echo e($dataAdmin->links('pagination::bootstrap-5')); ?>

      </nav>
    </div>
  </div>

  
  <div style="display:none">
    <select id="selectTypeOpt" class="form-select color-dropdown">
        <?php if(Session::get('adminTambah') == 'ok'): ?>
            <option value="bg-success">Success</option>
        <?php endif; ?>
        
        <?php if(Session::get('adminAlready') == 'ok'): ?>
            <option value="bg-warning">Warning</option>
        <?php endif; ?>
        
        <?php if(Session::get('adminEdit') == 'ok'): ?>
            <option value="bg-success">Success</option>
        <?php endif; ?>

        <?php if(Session::get('adminDelete') == 'ok'): ?>
            <option value="bg-success">Success</option>
        <?php endif; ?>
        
        <?php if(Session::get('adminError') == 'ok'): ?>
        <option value="bg-danger">Danger</option>
        <?php endif; ?>
    </select>
    <select class="form-select placement-dropdown" id="selectPlacement">
      <option value="top-0 end-0">Top right</option>
    </select>
    <button id="showToastPlacement" class="btn btn-primary d-block">Show Toast</button>
  </div>

  <div class="bs-toast toast toast-placement-ex m-2" role="alert" aria-live="assertive" aria-atomic="true" data-delay="2000">
    <div class="toast-header">
      <?php if(Session::get('adminError') == 'ok'): ?>
      <i class='bx bx-error-alt me-2'></i>
      <div class="me-auto fw-semibold"> Error</div>
      <?php else: ?>
      <i class='bx bx-check me-2'></i>
      <div class="me-auto fw-semibold">Sukses</div>
      <?php endif; ?>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body">
      <?php if(Session::get('adminTambah') == 'ok'): ?>
        Admin baru berhasil ditambahkan.
      <?php endif; ?>
      
      <?php if(Session::get('adminAlready') == 'ok'): ?>
        Username telah tersedia, mohon cek kembali.
      <?php endif; ?>
      
      <?php if(Session::get('adminEdit') == 'ok'): ?>
        Data admin berhasil diubah.
      <?php endif; ?>
      
      <?php if(Session::get('adminDelete') == 'ok'): ?>
        Data admin berhasil dihapus.
      <?php endif; ?>
      
      <?php if(Session::get('adminError') == 'ok'): ?>
        Terjadi kesalahan, silahkan ulangi proses.
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Modal Add -->
<div class="modal fade" id="modalForm" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="label-modal">Tambah Data Admin</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onclick="javascript:window.location.reload()"></button>
      </div>
      <form id="modal-form" action="<?php echo e(url('/data-admin/add')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="modal-body">
            <div class="row">
              <div class="col col-lg-12">
                <div id="imgAdmin"></div>
              </div>
            </div>
            <div class="row">
              <div class="col col-lg-12">
                  <div class="row">
                      <div class="col col-lg-6 mb-3">
                          <label for="nameBasic" class="form-label">Nama</label>
                          <input type="hidden" name="id" id="id-admin">
                          <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nama" id="nama-admin" name="nama" value="<?php echo e(old('nama')); ?>">
                          <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="form-text text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      
                      <div class="col col-lg-6 mb-3">
                          <label for="nameBasic" class="form-label">Username</label>
                          <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Uername" id="username-admin" name="username" value="<?php echo e(old('username')); ?>">
                          <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="form-text text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
              </div>
            </div>

            <div class="row">
              <div class="col col-lg-12">
                <div class="row">
                    <div class="col mb-3">
                      <label for="emailBasic" class="form-label">Role</label>
                      <select class="form-select" aria-label="Default select example" id="role-admin" name="role">
                          <option selected="">Pilih Role</option>
                          <option value="Administrator">Administrator</option>
                          <option value="Staff">Staff</option>
                      </select>
                    </div>
                
                    <div class="col mb-3">
                      <label for="nameBasic" class="form-label">Foto Admin</label>
                      <div class="input-group">
                      <input type="file" class="form-control <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto-admin" name="foto">
                      <input type="hidden" name="oldImage" id="oldImage">
                      </div>
                      <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="form-text text-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
              </div>
            </div>

            
            
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal" onclick="javascript:window.location.reload()">Batal</button>
          <button type="submit" id="btn-modal" class="btn btn-primary">Tambahkan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Delete Siswa -->
<div class="modal fade" id="modalHapus" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content" style="text-align:center;">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="/data-admin/delete" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <div class="modal-body">
          <div class="row">
            <div class="col mb-3">
              <label for="nameBasic">Yakin akan hapus data admin <strong id="label-del"></strong>?</label>
              <input type="hidden" id="id-del" name="id_del">
              <input type="hidden" name="oldImageDel" id="oldImageDel">
            </div>
          </div>

          <div class="row">
            <div class="col mb-3">
              <button type="button" class="btn btn-outline-secondary mt-2" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-danger mt-2">Hapus</button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="<?php echo e(asset('admin/assets/js/ui-toasts.js')); ?>"></script>
    <?php if(count($errors) > 0): ?>
    <script type="text/javascript">
      $(document).ready(function(){
          $("#btnModal").trigger("click");
      });
    </script>
    <?php endif; ?>

    <?php if(Session::get('adminTambah') == 'ok'): ?>
    <script>
      window.onload = function() {
        $("#showToastPlacement").click();
        }
    </script>
    <?php endif; ?>
    
    <?php if(Session::get('adminAlready') == 'ok'): ?>
    <script>
      window.onload = function() {
        $("#showToastPlacement").click();
        }
    </script>
    <?php endif; ?>

    <?php if(Session::get('adminEdit') == 'ok'): ?>
    <script>
      window.onload = function() {
        $("#showToastPlacement").click();
        }
    </script>
    <?php endif; ?>

    <?php if(Session::get('adminDelete') == 'ok'): ?>
    <script>
      window.onload = function() {
        $("#showToastPlacement").click();
        }
    </script>
    <?php endif; ?>

    <?php if(Session::get('adminError') == 'ok'): ?>
    <script>
      window.onload = function() {
        $("#showToastPlacement").click();
        }
    </script>
    <?php endif; ?>

    <script>
        function dataAdminEdit(element) {
          var id = $(element).attr('data-id');
          $.ajax({
            url: "/get-data-admin/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data) {
              var imgElement = $('#imgAdmin');
					    imgElement.empty();

              let {
                dataAdmin,
              } = data
              $('#modal-form').attr('action','<?php echo e(url("/data-admin/edit")); ?>');
              $('#id-admin').val(dataAdmin.id);
              $('#nama-admin').val(dataAdmin.nama);
              $('#username-admin').val(dataAdmin.username);
              $('#username-admin').prop('readonly', true);

              $('#oldImage').val(dataAdmin.foto);

              var selectElementRole = $('#role-admin')   
              selectElementRole.empty();
              selectElementRole.append(`
              <option>Pilih Role</option>
              <option value="Administrator">Administrator</option>
              <option value="Staff">Staff</option>
              `)
              $("#role-admin option[value='" + dataAdmin.role + "']").attr("selected", "selected");

              $('#modalForm').modal('show');
              $('#label-modal').text('Edit Data Admin');
              $('#btn-modal').text('Update Data');
              $('#imgAdmin').css("display","block");

              var imgs = dataAdmin.foto;
              var elem = document.createElement("img");
              elem.setAttribute("src", "/foto-admin/" + imgs);
              elem.className="rounded-circle avatar avatar-xl pull-up mb-2";
              document.getElementById("imgAdmin").appendChild(elem);
            }
          });
        }
      
        function dataAdminDel(element) {
          var id = $(element).attr('data-id');
          $.ajax({
            url: "/get-data-admin/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data) {
              let {dataAdmin} = data
              $('#id-del').val(dataAdmin.id);
              $('#label-del').text(dataAdmin.nama);
              $('#oldImageDel').val(dataAdmin.foto);
              $('#modalHapus').modal('show');
            }
          });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\_DATA KERJAAN\WEBSITE\LARAVEL\SMKNWongsorejo-Admin\resources\views/admin/pages/data-admin.blade.php ENDPATH**/ ?>