<!-- Footer -->
<footer class="content-footer footer bg-footer-theme">
  <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
    <div class="mb-2 mb-md-0">
      © <script>
      document.write(new Date().getFullYear())
      </script>
      , SMKN Wongsorejo
    </div>
  </div>
</footer>
<!-- / Footer --><?php /**PATH D:\_DATA KERJAAN\WEBSITE\LARAVEL\SMKNWongsorejo-Admin\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>