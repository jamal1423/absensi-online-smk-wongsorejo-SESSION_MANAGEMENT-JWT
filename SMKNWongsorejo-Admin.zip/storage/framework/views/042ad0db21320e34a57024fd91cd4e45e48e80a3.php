

<?php $__env->startSection('content'); ?>
<h4 class="fw-bold">
  <span class="text-muted fw-light">Admin /</span> Data Kehadiran
</h4>

<div class="card">
    <h5 class="card-header">List Data Kehadiran Siswa</h5>
    <div class="table-responsive text-nowrap">
        <table class="table table-striped" style="font-size: 14px">
            <thead>
                <tr>
                    <th>No.</th>
                    <th></th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Clock In</th>
                    <th>Clock Out</th>
                    <th>Lokasi</th>
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
                <?php $__empty_1 = true; $__currentLoopData = $dataKehadiran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$hadir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($dataKehadiran->firstItem()+$key); ?></td>
                    <td><img src="<?php echo e(asset('foto-siswa/'.$hadir->foto)); ?>" width="40px"></td>
                    <td><?php echo e($hadir->nis); ?></td>
                    <td><?php echo e($hadir->nama); ?></td>
                    <td><?php echo e($hadir->kelas); ?></td>
                    <td>
                        <span class="badge bg-label-success me-1"><?php echo e(date('d-m-Y H:i:s', strtotime($hadir->tgl_clock_in))); ?></span>
                    </td>
                    <td>
                        <?php if($hadir->clock_out == ""): ?>
                            <span class="badge bg-label-danger me-1">Belum Clock-Out</span>
                        <?php else: ?>
                            <span class="badge bg-label-success me-1"><?php echo e(date('d-m-Y H:i:s', strtotime($hadir->tgl_clock_out))); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($hadir->lokasi); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                <td colspan="5">Data tidak ditemukan.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="demo-inline-spacing">
            <nav aria-label="Page navigation">
                <?php echo e($dataKehadiran->links('pagination::bootstrap-5')); ?>

            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\_DATA KERJAAN\WEBSITE\LARAVEL\SMKNWongsorejo-Admin\resources\views/admin/pages/data-kehadiran.blade.php ENDPATH**/ ?>